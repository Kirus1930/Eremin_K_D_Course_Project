#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMessageBox"
#include <QtMath>
#include <math.h>
#include <stdio.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_descript_clicked()
{
    QMessageBox::information(nullptr, "Описание логарифма", "Общий вид логарифма: log(a, b)=x, где a - основание логарифма (a>0; a!=1), b - аргумент логарифма (b>0), x - значение логарифма. "
                                                            "Из определения логарифма следует: a^x=b");
}

void MainWindow::on_info_clicked()
{
    QMessageBox::information(nullptr, "Справочная информация", "Перед вводом значений необходимо выбрать искомое значение: основание, аргумент или значение логарифма. "
                                                               "'Подтвердить выбор' - выводит на экран названия значений, которые нужно ввести, рядом с полями ввода. "
                                                               "'Предпросмотр' - выводит на экран введенные значения в формате log(a, b)=x и a^x=b. "
                                                               "'Результат' - выполняет необходимые вычисления и выводит результат на экран");
}

void MainWindow::on_confirm_clicked()
{
    if (ui->base->isChecked()){
        ui->value_1->setText("Аргумент:");
        ui->value_2->setText("Значение:");
    }

    else if (ui->argument->isChecked()){
        ui->value_1->setText("Основание:");
        ui->value_2->setText("Значение:");
    }

    else if (ui->value->isChecked()){
        ui->value_1->setText("Основание:");
        ui->value_2->setText("Аргумент:");
    }

    else{
        QMessageBox::warning(nullptr, "Уведомление", "Выберите искомое значение");
    }
}

void MainWindow::on_perform_clicked()
{
    QString txt_1 = ui->edit_1->text();
    QString txt_2 = ui->edit_2->text();

    bool correct_1 = false;
    bool correct_2 = false;

    double val_1 = txt_1.toDouble(&correct_1);
    double val_2 = txt_2.toDouble(&correct_2);

    if (correct_1 && correct_2){
        if (ui->base->isChecked()){
            ui->value_1->setText("Аргумент");
            ui->value_2->setText("Значение");
            QMessageBox::information(nullptr, "Предпросмотр формулы", "log(a, " + txt_1 + ") = " + txt_2 + ";   a^" + txt_2 + " = " + txt_1);
        }

        else if (ui->argument->isChecked()){
            ui->value_1->setText("Основание");
            ui->value_2->setText("Значение");
            QMessageBox::information(nullptr, "Предпросмотр формулы", "log(" + txt_1 + ", b) = " + txt_2 + ";   " + txt_1 + "^" + txt_2 + " = b");
        }

        else if (ui->value->isChecked()){
            ui->value_1->setText("Основание");
            ui->value_2->setText("Аргумент");
            QMessageBox::information(nullptr, "Предпросмотр формулы", "log(" + txt_1 + ", " + txt_2 +") = x;    " + txt_1 + "^x = " + txt_2);
        }

        else{
            QMessageBox::warning(nullptr, "Ошибка", "Выберите искомое значение");
        }
    }

    else{
        QMessageBox::warning(nullptr, "Ошибка", "Вводить можно только действительные числа");
    }
}

double log_base(double argument, double value){
    if (argument <= 0){
        return QMessageBox::warning(nullptr, "Ошибка", "Значение Аргумента должно быть больше 0");
    }
    else{
        return pow(argument, value);
    }
}

double log_arg(double base, double value){
    if (base <= 0 || base == 1){
        return QMessageBox::warning(nullptr, "Ошибка", "Значение Основания должно быть больше 0 и не равно 1");
    }
    else{
        return pow(base, value);
    }
}

double log_val(double argument, double base){
    if (base <= 0 || base == 1){
        return QMessageBox::warning(nullptr, "Ошибка", "Значение Основания должно быть больше 0 и не равно 1");
    }
    if (argument <= 0){
        return QMessageBox::warning(nullptr, "Ошибка", "Значение Аргумента должно быть больше 0");
    }
    else{
        return log(argument) / log(base);
    }
}

void MainWindow::on_result_clicked()
{
    QString txt_1 = ui->edit_1->text();
    QString txt_2 = ui->edit_2->text();

    bool correct_1 = false;
    bool correct_2 = false;

    double val_1 = txt_1.toDouble(&correct_1);
    double val_2 = txt_2.toDouble(&correct_2);

    if (correct_1 && correct_2){
        double result;
        if (ui->base->isChecked()){
            ui->value_1->setText("Аргумент");
            ui->value_2->setText("Значение");

            result = log_base(val_1, 1 / val_2);
            ui->res_output->setNum(result);
        }

        else if (ui->argument->isChecked()){
            ui->value_1->setText("Основание");
            ui->value_2->setText("Значение");

            result = log_arg(val_1, val_2);
            ui->res_output->setNum(result);
        }

        else if (ui->value->isChecked()){
            ui->value_1->setText("Основание");
            ui->value_2->setText("Аргумент");

            result = log_val(val_2, val_1);
            ui->res_output->setNum(result);
        }

        else{
            ui->res_output->setText("Ошибка: Выберите искомое значение!");
        }
    }

    else{
        ui->res_output->setText("Ошибка: Вводить можно только действительные числа!");
    }
}

